package com.factory;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
	
	private static ConnectionFactory connectionFactoryObj = new ConnectionFactory();
	
	public static ConnectionFactory getConnectionFactory() {
		return connectionFactoryObj;
	}
	
	public Connection openConnection() {
		 Connection con = null;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","thinesh","thinesh");
		}catch(Exception exp) {
			System.out.println(exp+" SQL EXP ..! While Connecting DB");
		}
		
		return con;
	}

	public void closeConnection(Connection con) {
		try {
				if(con != null)
					con.close();
			
		}catch(Exception exp) {
			System.out.println(exp+" SQL EXP ..! While Closing DB");
		}
	}
}
