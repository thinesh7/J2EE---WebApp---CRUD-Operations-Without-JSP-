package com.factory;

import com.dao.StudentDAO;
import com.dao.StudentDAOImplementation;

public class StudentDAOFactory {
	
	private static StudentDAO studentDao = null;
	
	static {
		studentDao = new StudentDAOImplementation();
	}
	
	public static StudentDAO getStudentDAO() {
		return studentDao;
	}
}
