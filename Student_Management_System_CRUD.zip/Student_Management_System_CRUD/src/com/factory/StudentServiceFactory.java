package com.factory;

import com.service.StudentService;
import com.service.StudentServivceImplementation;

public class StudentServiceFactory {
	
	private static StudentService studentServiceImplObj = m1();

	private static StudentService m1() {
		return new StudentServivceImplementation();
	}
	
	public static StudentService getStudentService() {
		return studentServiceImplObj;
	}

}
