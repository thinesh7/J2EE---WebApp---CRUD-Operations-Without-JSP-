package com.dao;
import com.beans.Student;

public interface StudentDAO {
	
	public String add(Student student);
	public Student search(String sid);
	public String update(Student student);
	public String delete(String sid);
	
	String SELECT_STUDENT_QUERY = "SELECT * FROM STUDENT WHERE SID = ";
	
	String INSERT_STUDENT_QUERY = "INSERT INTO STUDENT VALUES (?,?,?)";
	
	String UPDATE_STUDENT_QUERY = "UPDATE STUDENT SET SNAME=?, SADDR=? WHERE SID=?";

	String DELETE_STUDENT_QUERY = "DELETE STUDENT WHERE SID=?";

}
