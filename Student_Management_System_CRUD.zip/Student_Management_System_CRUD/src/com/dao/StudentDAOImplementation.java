package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.factory.ConnectionFactory;

import com.beans.Student;

public class StudentDAOImplementation implements StudentDAO{
	
	ConnectionFactory conFactory = ConnectionFactory.getConnectionFactory();

	@Override
	public String add(Student student) {
		
		String status = "";
		Connection con = null;
		PreparedStatement pst = null;
		Student std=null;
		
		try {
		
			std = search(student.getSid());
			
			if(std == null) {
				
				con = conFactory.openConnection();
				pst = con.prepareStatement(StudentDAO.INSERT_STUDENT_QUERY);
				pst.setString(1, student.getSid());
				pst.setString(2, student.getSname());
				pst.setString(3, student.getSaddr());
				
				int count = pst.executeUpdate();
				
				if(count == 1) {
					status = "Success";
				}
				else {
					status = "Faliure";
				}
			}
			else {
				status = "Existed";
			}
		
		}
		catch(Exception exp) {
			status = "Faliure";
			System.out.println(exp+" SQL EXP ..! in Add");
		}
		finally {
			conFactory.closeConnection(con);
		}
				
		return status;
	}

	@Override
	public Student search(String sid) {
		
		Student student = null;
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		
		try {
			con = conFactory.openConnection();
			st = con.createStatement();
			rs = st.executeQuery(StudentDAO.SELECT_STUDENT_QUERY+"'"+sid+"'");
			
			if(rs.next()) {				
				student = new Student();
				
				student.setSid(rs.getString(1));
				student.setSname(rs.getString("SNAME"));
				student.setSaddr(rs.getString(3));
			}
			else {
				student = null;
			}
		}
		catch( Exception exp ) {
			System.out.println(exp+" SQL EXP ..! in Search");
		}
		finally {
			conFactory.closeConnection(con);
		}
		
		return student;
	}

	@Override
	public String update(Student student) {
		
		String status  = "";
		Connection con = null;
		PreparedStatement pst = null;
		
		try {
			con = conFactory.openConnection();
			pst = con.prepareStatement(StudentDAO.UPDATE_STUDENT_QUERY);
			pst.setString(1, student.getSname());
			pst.setString(2, student.getSaddr());
			pst.setString(3, student.getSid());
			
			int count = pst.executeUpdate();
			
			if(count==1) {
				status="Success";
			}
			else {
				status="Faliure";
			}			
		}
		catch(Exception exp) {
			status="Faliure";
			System.out.println(exp+" SQL EXP ! in Update");
		}
		finally {
			conFactory.closeConnection(con);
		}
		
		return status;
	}

	@Override
	public String delete(String sid) {
		
		String status = "";		
		Connection con = null;
		PreparedStatement pst = null;
		
		try {
			
			con = conFactory.openConnection();
			pst = con.prepareStatement(StudentDAO.DELETE_STUDENT_QUERY);
			pst.setString(1, sid);
			
			int count = pst.executeUpdate();
			
			if(count==1) {
				status ="Success";
			}
			else {
				status = "Faliure";
			}
			
		}
		catch(Exception exp) {
			status = "Failure";
			System.out.println(exp+" SQL EXP ! in Delete ");
		}
		finally {
			conFactory.closeConnection(con);
		}
		
		return status;
	}

}
