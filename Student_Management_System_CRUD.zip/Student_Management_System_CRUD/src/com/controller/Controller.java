package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.beans.Student;
import com.factory.StudentServiceFactory;
import com.service.StudentService;

@WebServlet("*.do")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String requestURL = request.getRequestURI(); 
		
		String sid =null,sname=null ,saddrs =null;
		
		Student student = null;
		
		RequestDispatcher rd = null;
		
		StudentService studentService = StudentServiceFactory.getStudentService();	
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
			// Add:
			if(requestURL.endsWith("add.do")) { 
				
				sid    = request.getParameter("sid");
				sname  = request.getParameter("sname");
				saddrs = request.getParameter("saddrs");
				
				if(sid!="" && sname!="" && saddrs !="") {
						student = new Student(sid.toUpperCase(),sname,saddrs.toUpperCase());
						
						String status = studentService.addStudent(student);
						
						if(status.equals("Success")) {
							
							rd = request.getRequestDispatcher("success.html");
							rd.forward(request, response);
						} 
						else if(status.equals("Existed")) {
							rd = request.getRequestDispatcher("studentalreadyexisted.html");
							rd.forward(request, response);
						}
						else if(status.equals("Faliure")) {
							rd = request.getRequestDispatcher("failure.html");
							rd.forward(request, response);
						}
				}
				else {
					rd = request.getRequestDispatcher("failure.html");
					rd.forward(request, response);
				}
				
			}
			
			// Search:
			if(requestURL.endsWith("search.do")) {
				
				sid = request.getParameter("sid").toUpperCase();
				
				student = studentService.searchStudent(sid);
				
				if(student != null) {					
					out.print("<html><body><br><br><br>");
					out.print("<h1 style='color:red;' align = 'center' >Studnet Details<h1><table border='1' width=30% height=40% align = 'center'style='color:white;'>");
					out.print("<tr> <th align = 'center'>SID</th> <th align = 'center'>SNAME</th> <th align = 'center'>SADDR</th></tr>");
					out.print("<tr> <td align = 'center'>"+student.getSid()+"</td>");
					out.print("<td align = 'center'>"+student.getSname()+"</td>");
					out.print("<td align = 'center'>"+student.getSaddr()+"</td></tr>");
					out.print("</table></html></body>");					
				}
				else {
					rd = request.getRequestDispatcher("studentNotExisted.html");
					rd.forward(request, response);
				}
			}
			
			// Update -> Check User if there Edit it
			
			if(requestURL.endsWith("update.do")) {
				
				sid = request.getParameter("sid").toUpperCase();
				
				student = studentService.searchStudent(sid);
				
				if(student != null) { 
					
					out.print("<html><body><br><br><br>");
					out.print("<h1 style='color:red;' align = 'center'>Studnet Details<h1>");
					out.print("<form method='post' action='./edit.do'><table width=30% height=40% align = 'center'style='color:white;'>");
					out.print("<tr> <td>SID</td> <td> <input type='text' readonly='readonly' value='"+student.getSid()+"'"+"></td></tr>");
					out.print("<tr> <td>SNAME</td> <td> <input name='sname' type='text' value='"+student.getSname()+"'"+"></td></tr>");
					out.print("<tr> <td>SADDR</td> <td> <input name='saddrs' type='text' value='"+student.getSaddr()+"'"+"></td></tr>");
					out.print("<input name='sid' type='hidden' value='"+student.getSid()+"'>");
					out.print("<tr> <td></td> <td align = 'center' ><input type='submit' value='Edit'></td></tr>");
					out.print("</form></table></html></body>");
					
				}
				else {
					rd = request.getRequestDispatcher("studentNotExisted.html");
					rd.forward(request, response);
				}
			}
			
			// Edit Form:
			
			if(requestURL.endsWith("edit.do")) {
								
				sid    = request.getParameter("sid");
				sname  = request.getParameter("sname");
				saddrs = request.getParameter("saddrs");
				
				if(sid!="" && sname!="" && saddrs !="") {
						student = new Student(sid.toUpperCase(),sname,saddrs.toUpperCase());
						
						String status = studentService.updateStudent(student);
						
						if(status.equals("Success")) {							
							rd = request.getRequestDispatcher("success.html");
							rd.forward(request, response);
						} 
						else if(status.equals("Faliure")) {
							rd = request.getRequestDispatcher("failure.html");
							rd.forward(request, response);
						}
				}
				else {
					rd = request.getRequestDispatcher("failure.html");
					rd.forward(request, response);
				}
				
			}
			
			//Delete:
			
			if(requestURL.endsWith("delete.do")) {
				
				sid = request.getParameter("sid").toUpperCase();
				
				student = studentService.searchStudent(sid);
				
				if(student != null) {
					
					String status = studentService.deleteStudent(sid);
					
					if(status.contentEquals("Success")) {
						rd= request.getRequestDispatcher("success.html");
						rd.forward(request, response);
					}
					else if(status.contentEquals("Faliure")) {
						rd = request.getRequestDispatcher("failure.html");
						rd.forward(request, response);
					}
					
				}
				else {
					rd = request.getRequestDispatcher("studentNotExisted.html");
					rd.forward(request, response);
				}
								
			}
		
	}
	
}
